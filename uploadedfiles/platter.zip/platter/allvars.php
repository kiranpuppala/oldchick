<?php
define('IMAGE_PATH','images/');
define('POST_IMAGE_PATH','postimages/');

define('MESS_IMAGE_PATH','messimages/');
define('FILE_SIZE','1000000');
define('DB_ADDR','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','project');
define('subject','srkr network');
?>