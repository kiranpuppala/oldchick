﻿<?php

$receiver_id=$_GET['id'];
header("Location:messaging.php?id=$receiver_id");

 
?>